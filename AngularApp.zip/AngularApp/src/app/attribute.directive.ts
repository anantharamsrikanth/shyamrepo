import { Directive ,ElementRef,Renderer} from '@angular/core';

@Directive({
  selector: '[appAttribute]'
})
export class AttributeDirective {

  constructor(private element:ElementRef,render:Renderer) { 
    render.setElementStyle(element.nativeElement, 'backgroundColor','gray');
  }

}
