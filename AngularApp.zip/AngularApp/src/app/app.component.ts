import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(){
    // this.route.params.subscribe( params => console.log(params.id) );
  }
  title = 'app';
  data="good";
  childdata:string;
  person:string="good";
  twowayvalue:string="two way binidng daat";
  show:boolean=true;
  information:string="hai here yiu can get soe information ";
  getdata(event:any){
    // alert();
    // console.log(event);
  }
 

  getinput(data:any){
    console.log(data.target.value);
  }

 


}
