import { Directive ,ViewContainerRef,TemplateRef, Input} from '@angular/core';
// import { element } from '../../node_modules/protractor';

@Directive({
  selector: '[appStructural]'
})
export class StructuralDirective {

  constructor(private elem:TemplateRef<any>,private viewref:ViewContainerRef) {
 
   
  }
  @Input() set appStructural(condition:boolean){
   if(condition){
    this.viewref.createEmbeddedView(this.elem);
   }else{
     this.viewref.clear();
   }
  }

}
