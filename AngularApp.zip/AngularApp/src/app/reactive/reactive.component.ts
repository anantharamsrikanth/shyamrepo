import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {  Router } from '@angular/router';
// import { formGroupNameProvider } from '../../../node_modules/@angular/forms/src/directives/reactive_directives/form_group_name';
@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {

  constructor() { 
    ((params)=>{
      console.log(params);
      
    })
    // this.route.paramMap.subscribe(params => {
    //   console.log(params.get('id'));
    //   // this.username = params.get('username');
    // });
  }
  gotoreact(id:any){
    // console.log(id);
    // this.router.navigate(['/templ',id])
  }
  array=['male','female'];

  formreactive:FormGroup;
  ngOnInit() {
    this.formreactive=new FormGroup({
      'username':new FormControl(null,[Validators.required,Validators.pattern(/^[a-zA-Z]*$/)]),
      'email':new FormControl(null,[Validators.required,Validators.email]),
      'gender':new FormControl(null,Validators.required)
    });
  }
  onsubmit(){
   console.log(this.formreactive);   
  }

}
