import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms'; 
import { AttributeDirective } from './attribute.directive';
import { StructuralDirective } from './structural.directive';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';
import { ReactiveComponent } from './reactive/reactive.component';

@NgModule({
  declarations: [
    AppComponent,
    AttributeDirective,
    StructuralDirective,
    TemplatedrivenComponent,
    ReactiveComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    ReactiveFormsModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
