import { Component, OnInit } from '@angular/core';
import { NgForm } from '../../../node_modules/@angular/forms';
// import {ActivatedRoute, Route, Router} from "@angular/router";
@Component({
  selector: 'app-templatedriven',
  templateUrl: './templatedriven.component.html',
  styleUrls: ['./templatedriven.component.css']
})
export class TemplatedrivenComponent implements OnInit {

  constructor() { }
  user={
    name:"",
    email:""
  }

  ngOnInit() {
    // this.route.params.subscribe(()=>{
    //   console.log(params);
    // })
    // console.log(this.route.snapshot.params.id);
  }
  onsubmit(form:NgForm){
   
    // console.log(form.value);
    this.user.name=form.value.username;
    this.user.email=form.value.emaail;  


  }

}
